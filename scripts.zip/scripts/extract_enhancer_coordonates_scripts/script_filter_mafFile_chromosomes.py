import sys

input_file = sys.argv[1]
output_file = sys.argv[2]
chromosome = sys.argv[3]

found_chromosome = False
with open(input_file, "r") as f_input, open(output_file, "w") as f_output:
    found_chromosome = False

    for line in f_input:
        if line.startswith("s hg38.chr") :
            chr = line.split(" ")[1].split(".")[1]
            if line.startswith(f"s hg38.{chr}") and chr == chromosome :
                found_chromosome = True
                print("True",chr)

            if line.startswith(f"s hg38.{chr}") and chr != chromosome :
                found_chromosome = False
                print("False",chr)

        if found_chromosome == True:
            f_output.write(line)
            print(line)
    

