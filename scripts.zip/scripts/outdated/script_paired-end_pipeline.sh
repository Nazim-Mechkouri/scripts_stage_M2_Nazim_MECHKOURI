#!/bin/bash
#SBATCH --job-name=atacseq_pipeline
#SBATCH --output=atacseq_pipeline_%j.log
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --time=24:00:00

# Load modules
module load trimmomatic
module load bowtie2
module load samtools

# Input parameters
READ1=$1
READ2=$2
REFERENCE_GENOME=$3
OUTPUT_PREFIX=$4
ADAPTERS=$5

# Step 1: Trimming
echo "Starting trimming..."
trimmomatic PE -threads 8 \
    $READ1 $READ2 \
    ${OUTPUT_PREFIX}_trimmed_R1_paired.fastq ${OUTPUT_PREFIX}_trimmed_R1_unpaired.fastq \
    ${OUTPUT_PREFIX}_trimmed_R2_paired.fastq ${OUTPUT_PREFIX}_trimmed_R2_unpaired.fastq \
    ILLUMINACLIP:$ADAPTERS:2:30:10 SLIDINGWINDOW:4:20 MINLEN:25
echo "Trimming completed."

# Step 2: Alignment with Bowtie2
echo "Starting alignment..."
bowtie2 -p 8 -x $REFERENCE_GENOME \
    -1 ${OUTPUT_PREFIX}_trimmed_R1_paired.fastq \
    -2 ${OUTPUT_PREFIX}_trimmed_R2_paired.fastq \
    -S ${OUTPUT_PREFIX}.sam
echo "Alignment completed."

# Step 3: Convert SAM to BAM
echo "Converting SAM to BAM..."
samtools view -bS ${OUTPUT_PREFIX}.sam > ${OUTPUT_PREFIX}.bam
echo "Conversion to BAM completed."

# Step 4: Sort BAM
echo "Sorting BAM..."
samtools sort ${OUTPUT_PREFIX}.bam -o ${OUTPUT_PREFIX}_sorted.bam
echo "Sorting completed."

# Step 5: Index BAM
echo "Indexing BAM..."
samtools index ${OUTPUT_PREFIX}_sorted.bam
echo "Indexing completed."

echo "Pipeline completed successfully."
