#!/bin/bash
#SBATCH --job-name=atacseq_pipeline
#SBATCH --output=atacseq_pipeline_%j.log
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --time=24:00:00

# Load modules
module load trimmomatic
module load bowtie2
module load samtools

# Input parameters
READ_DIR=$1
REFERENCE_GENOME=$2
ADAPTERS=$3
OUTPUT_DIR=$4

# Create output directory if it doesn't exist
mkdir -p $OUTPUT_DIR

# Process each FASTQ file in the directory
for READ in $READ_DIR/*.fastq; do
  # Extract the base name of the file for output naming
  BASE_NAME=$(basename $READ .fastq)
  OUTPUT_PREFIX=$OUTPUT_DIR/$BASE_NAME

  # Step 1: Trimming
  echo "Starting trimming for $READ..."
  trimmomatic SE -threads 8 \
      $READ ${OUTPUT_PREFIX}_trimmed.fastq \
      ILLUMINACLIP:$ADAPTERS:2:30:10 SLIDINGWINDOW:4:20 MINLEN:25
  echo "Trimming completed for $READ."

  # Step 2: Alignment with Bowtie2
  echo "Starting alignment for ${OUTPUT_PREFIX}_trimmed.fastq..."
  bowtie2 -p 8 -x $REFERENCE_GENOME \
      -U ${OUTPUT_PREFIX}_trimmed.fastq \
      -S ${OUTPUT_PREFIX}.sam
  echo "Alignment completed for ${OUTPUT_PREFIX}_trimmed.fastq."

  # Step 3: Convert SAM to BAM
  echo "Converting SAM to BAM for $OUTPUT_PREFIX..."
  samtools view -bS ${OUTPUT_PREFIX}.sam > ${OUTPUT_PREFIX}.bam
  echo "Conversion to BAM completed for $OUTPUT_PREFIX."

  # Step 4: Sort BAM
  echo "Sorting BAM for $OUTPUT_PREFIX..."
  samtools sort ${OUTPUT_PREFIX}.bam -o ${OUTPUT_PREFIX}_sorted.bam
  echo "Sorting completed for $OUTPUT_PREFIX."

  # Step 5: Index BAM
  echo "Indexing BAM for $OUTPUT_PREFIX..."
  samtools index ${OUTPUT_PREFIX}_sorted.bam
  echo "Indexing completed for $OUTPUT_PREFIX."

  # Cleanup intermediate files
  rm ${OUTPUT_PREFIX}.sam ${OUTPUT_PREFIX}.bam
done

echo "Pipeline completed successfully for all files."
